﻿using System;

namespace BooleanLogicalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            bool x = true, y =false;

            //x & y

            Console.WriteLine("X & Y is: {0}", (x&y));

            //x | y

            Console.WriteLine("X | Y is: {0}", (x|y));

            //x ^ y

            Console.WriteLine("X ^ Y is: {0}", (x^y));

            //x && y

            Console.WriteLine("X && Y is: {0}", (x&&y));

            //x || y

            Console.WriteLine("X || Y is: {0}", (x || y));

            //!(x && y)

            Console.WriteLine("!(X && Y) is: {0}", !(x&&y));

        }
    }
}
