﻿using System;

namespace ComparisonOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x , y;

            Console.Write("Enter any value for a:");
            x = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter any value for b:");
            y = Convert.ToInt32(Console.ReadLine());

            if(x>y)
            Console.WriteLine("X is greater than Y.");

            if(x<y)
            Console.WriteLine("X is less than Y.");

            if(x>=y)
            Console.WriteLine("X is greater than and equal to Y.");

            if(x<=y)
            Console.WriteLine("X is less than and equal to Y.");   
            
        }
    }
}
