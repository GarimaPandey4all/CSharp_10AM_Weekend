﻿using System;

namespace BitwiseOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x=3, y=5;

            bool a=true, b=false;

            //x & y

            Console.WriteLine("X & Y is: {0}", (x&y));

            Console.WriteLine("X && Y is: {0}", (a&&b));

            //x | y

            Console.WriteLine("X | Y is: {0}", (x | y));

            //x ^ y

            Console.WriteLine("X ^ Y is: {0}", (x ^ y));

        }
    }
}
