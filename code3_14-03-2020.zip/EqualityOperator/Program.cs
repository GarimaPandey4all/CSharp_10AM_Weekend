﻿using System;

namespace EqualityOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;

                Console.WriteLine("Enter value for x:");
                x = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter value for y:");
                y = Convert.ToInt32(Console.ReadLine());

                if(x==y)
                Console.WriteLine("X is equal to Y");

                if(x != y)
                Console.WriteLine("X is not equal to Y");
        }
    }
}
