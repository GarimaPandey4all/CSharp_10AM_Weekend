﻿using System;

namespace AssignmentOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=10, c=0;

            //c += a;  //c= c + a;  

            //c -= a;  // c= c-a;      

            //c *= a; // c= c*a;

            //c /= a; //c = c/a;

            //c %= a; //c = c%a;

            string str = null;

            str ??= "Hello World!";

            //Console.WriteLine("C is {0}", c);

            Console.WriteLine("Str is: {0}", str??= "Hello World!");
            
        }
    }
}
