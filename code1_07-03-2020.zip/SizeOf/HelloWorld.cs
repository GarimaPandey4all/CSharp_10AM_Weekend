﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {   
            //int num;
            Console.WriteLine("Hello How are you?");
            Console.WriteLine("Size of int: {0}", sizeof(int));
            Console.WriteLine("Size of char: {0}", sizeof(char));
             Console.WriteLine("Size of double: {0}", sizeof(double));
             Console.WriteLine("Size of float: {0}", sizeof(float));
             //Console.WriteLine("Size of string: {0}", sizeof(string));
             
             }
    }
}
