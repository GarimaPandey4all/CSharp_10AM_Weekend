﻿using System;

namespace Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=30, b=50, c;

            c= a+b;

            c=70;

            Console.WriteLine("Addition of Two Numbers:{0}", c);
        }
    }
}
