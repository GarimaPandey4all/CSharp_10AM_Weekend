﻿using System;

namespace EvenOdd
{
    class Program
    {
        static void Main(string[] args)
        {   
            int number=3;

            if((number % 2)==0)
            {
            Console.WriteLine("Number is Even");
            }

            else
            {
                Console.WriteLine("Number is Odd");
            }

        }
    }
}
