﻿using System;

namespace ArithmeticOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());
        
            //Addition

            Console.WriteLine("Addition is: {0}", a+b);

            //Subtraction

            Console.WriteLine("Subtraction is: {0}", a-b);

            //Multiplication

            Console.WriteLine("Multiplication is: {0}", a*b);

            //Division

            Console.WriteLine("Division is: {0}", a/b);

            //Modulus or Remainder

            Console.WriteLine("Modulus is: {0}", a%b);

            //Pre and Post Increment

            Console.WriteLine("Pre-Increment is: {0}", ++a);

            Console.WriteLine("Post-Increment is: {0}", a++);

            Console.WriteLine("A is: {0}", a);

            //Pre and Post Decrement

            Console.WriteLine("Pre-Decrement is: {0}", --b);

            Console.WriteLine("Post-Decrement is: {0}", b--);

            Console.WriteLine("B is: {0}", b);
            
            //Unary Plus

            Console.WriteLine("Unary Plus is: {0}", +b);

            //Unary Minus

            Console.WriteLine("Unary Minus is: {0}", -b);
        }
    }
}
