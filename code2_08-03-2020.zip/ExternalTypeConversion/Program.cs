﻿using System;

namespace ExternalTypeConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            double externalD = 3456.68;
            int i;

            i = (int)externalD;

            Console.WriteLine("I is:{0}", i);
        }
    }
}
