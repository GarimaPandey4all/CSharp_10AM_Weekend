﻿using System;

namespace Variables_DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            string FirstName;
            string LastName;            

            Console.WriteLine("Enter your FirstName:");
            FirstName = Console.ReadLine();

            Console.WriteLine("Enter your LastName:");
            LastName = Console.ReadLine();

            Console.WriteLine("Concatenation of two Strings:{0}", FirstName + LastName);            

        }
    }
}
