﻿using System;

namespace CalculatorProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b; //a, b= operands, a+b=expression

            Console.WriteLine("Enter value for a:");
            a= Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b:");
            b= Convert.ToInt32(Console.ReadLine());

            //Addition 

            Console.WriteLine("Addition is:{0}", a+b);

            //Subtraction

            Console.WriteLine("Subtraction is:{0}", a-b);

            //Multiplication

            Console.WriteLine("Multiplication is:{0}", a*b);

            //Division

            Console.WriteLine("Division is:{0}", a/b);

            //Modulus

            Console.WriteLine("Modulus is:{0}", a%b);


        }
    }
}
