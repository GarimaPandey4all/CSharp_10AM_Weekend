﻿using System;

namespace Variables_DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;            

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32((Console.ReadLine()));

            Console.WriteLine("Addition of two numbers is:{0}", a + b);            

        }
    }
}
