﻿using System;

namespace SwitchExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int grade = 3;

            switch(grade)
            {   
                case 1:
                Console.WriteLine("This is case A.");
                break;
                
                case 2:
                
                case 3:
                Console.WriteLine("This is case C.");
                break;

                default:
                Console.WriteLine("Not Matched with any case.");
                break;
            }
        }
    }
}
