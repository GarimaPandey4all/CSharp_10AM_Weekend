﻿using System;

namespace IfExampleLargestNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=10, b=20, c=30;

            if(a>b && a>c)
            Console.WriteLine("A is greater than b and c.");

            if(b>c)
            Console.WriteLine("B is greater than c.");

            if(b>a)
            Console.WriteLine("B is greater than A.");

            if(c>a)
            Console.WriteLine("C is greater than A.");

            if(c>b)
            Console.WriteLine("C is greater than B.");

            Console.WriteLine("Value of a={0}, b={1}, and c={2}.", a, b, c);

        }
    }
}
