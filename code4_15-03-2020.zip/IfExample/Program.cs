﻿using System;

namespace IfExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=30, b=50; //Variable declaration and initialization

            if(a<b)
                Console.WriteLine("A is less than B.");

            Console.WriteLine("Value of a {0} and b {1}.", a, b);
        }
    }
}
