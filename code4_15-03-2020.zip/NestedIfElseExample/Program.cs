﻿using System;

namespace NestedIfElseExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=100, b=200;

            if(a==100)
            {
                    if(b==200)
                            {
                                Console.WriteLine("Value of A={0} and B={1}.",a, b);
                            }
          }
        }
    }
}
