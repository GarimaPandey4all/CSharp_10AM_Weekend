﻿using System;

namespace SwitchExample
{
    class Program
    {
        static void Main(string[] args)
        {
            char grade = 'B';

            switch(grade)
            {   
                case 'A':
                Console.WriteLine("This is case A.");
                break;
                
                case 'B':
                
                case 'C':
                Console.WriteLine("This is case C.");
                break;

                default:
                Console.WriteLine("Not Matched with any case.");
                break;
            }
        }
    }
}
