﻿using System;

namespace IfElse_IfElseExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=10, b=40, c=20;

            if(a>b && a>c)
            Console.WriteLine("A is greater.");
            else if(b>c)
            Console.WriteLine("B is greater.");
            else
            Console.WriteLine("C is greater.");

            Console.WriteLine("Value of A={0}, B={1}, and C={2}.",a, b, c);
        }
    }
}
