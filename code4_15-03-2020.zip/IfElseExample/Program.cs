﻿using System;

namespace IfElseExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int a=100, b=300;

            if(a>b)
            Console.WriteLine("A is greater than B.");
            else
            Console.WriteLine("B is greater than A.");

            Console.WriteLine("Value of a={0} and b={1}", a, b);

        }
    }
}
